$(function () {
  $('[data-toggle="popover"]').popover();
});
