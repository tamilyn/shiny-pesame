This example demonstrates the feature of editing tables, which can be enabled by the argument `editable = TRUE`. Double-click a cell to edit its value. In the server-side processing mode, please note that you have to use `replaceData()` to update the data in the server logic.

**DT** (>= 0.2.30) is required to run this example.
